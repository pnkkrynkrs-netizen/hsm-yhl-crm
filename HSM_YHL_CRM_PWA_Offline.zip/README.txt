HSM & YHL CRM PWA
Archivos: index.html, manifest.webmanifest, service-worker.js, icons/.
La PWA necesita HTTPS para instalarse en iPhone y para que Service Worker funcione.
Abrir el HTML desde Archivos no es suficiente.
Una vez publicada: Safari > Compartir > Añadir a pantalla de inicio.
La base de datos usa IndexedDB y el CRM puede funcionar offline después de la primera carga.
